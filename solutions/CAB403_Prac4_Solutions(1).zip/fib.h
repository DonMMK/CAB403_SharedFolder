#ifndef __FIB_H__
#define __FIB_H__

// pre: n > 0
// post: first n numbers of the Fibonacci sequenced are printed to STDOUT
void fib(int n);

#endif //__FIB_H__
