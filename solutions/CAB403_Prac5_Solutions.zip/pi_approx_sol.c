#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    long num_steps = 10000000;
    double step;
    double pi, sum = 0.0;
    step = 1.0 / num_steps;
    #pragma omp parallel
    {
        double localSum = 0.0;
        #pragma omp for
        for (int i = 0; i < num_steps; i++)
        {
            double x = (i + .5) * step;
            localSum += 4.0 / (1.0 + x * x);
        }
        #pragma omp critical
        sum += localSum;
    }

    pi = step * sum;
    printf("The value for pi = %.18f\n", pi);
    return EXIT_SUCCESS;
}
